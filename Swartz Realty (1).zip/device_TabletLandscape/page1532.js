if (window.VarCurrentView) VarCurrentView.set('TabletLandscape');
function init_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

}
shape1568.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj1568inner\"><svg viewBox=\"0 0 824 103\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(412 51.5)\" style=\"\">\n	<path d=\"M 51.5 0 L 772.5 0 A 51.5 51.5 0 0 1 824 51.5 L 824 51.5 A 51.5 51.5 0 0 1 772.5 103 L 51.5 103 A 51.5 51.5 0 0 1 0 51.5 L 0 51.5 A 51.5 51.5 0 0 1 51.5 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55); pointer-events: auto;\" transform=\"translate(0 0) translate(-412, -51.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(412 51.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 168px; top: 25px; width: 824px; height: 103px; z-index: 0; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1568",
	htmlId:		"tobj1568",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Pill"
	},
	objData:	{"a":[0,32,0,[168,25.0000000000001,824,103]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":168,"y":25,"width":824,"height":103},"bTriggerScreenRdrOnShow":false,"bDiscoverable":false,"altValue":"Pill","titleValue":"Pill"}
};
text1567.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 849px; min-height: 111px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 839px; min-height: 101px;\"><p style=\"text-align: center;\"><span style=\"font-size:36pt; color: rgb(255, 0, 255); font-family: Impact, sans-serif;\">Final Checklist for Move-In Readiness</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 171px; top: 37px; width: 849px; height: 111px; z-index: 1;",
	cssClasses:	"",
	id:		"1567",
	htmlId:		"tobj1567",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 2"
	},
	objData:	{"a":[0,32,0,[171,37,849,111]],"rcdOvr":{"res":0},"textShadowEffect":{"opacity":"0.9","depth":8,"color":"#000000","blurradius":5,"shadowtype":2,"bHasShadow":true,"dir":315},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":171,"y":37,"width":849,"height":111},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
shape1566.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj1566inner\"><svg viewBox=\"0 0 971 505\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(485.5 252.5)\" style=\"\">\n	<path d=\"M 126.25 0 L 844.75 0 A 126.25 126.25 0 0 1 971 126.25 L 971 378.75 A 126.25 126.25 0 0 1 844.75 505 L 126.25 505 A 126.25 126.25 0 0 1 0 378.75 L 0 126.25 A 126.25 126.25 0 0 1 126.25 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.75;filter:alpha(opacity=75); pointer-events: auto;\" transform=\"translate(0 0) translate(-485.5, -252.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(485.5 252.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.75;filter:alpha(opacity=75);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 21px; top: 135px; width: 971px; height: 505px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1566",
	htmlId:		"tobj1566",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rounded Rectangle"
	},
	objData:	{"a":[0,32,0,[20.999999999999943,135.0000000000001,971,505]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":21,"y":135,"width":971,"height":505},"bTriggerScreenRdrOnShow":false,"bDiscoverable":false,"altValue":"Rounded Rectangle","titleValue":"Rounded Rectangle"}
};
text1565.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 633px; min-height: 299px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 623px; min-height: 289px;\"><ul style=\"padding-inline-start: 27px;\">\n	<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n	<p><span><strong><span style=\"font-size:14pt; font-family:Georgia, serif; color:rgb(89, 126, 170)\">Develop a final move-in day checklist to ensure that nothing is overlooked. Include reminders to:</span></strong></span></p>\n\n	<ul style=\"padding-inline-start: 27px;\">\n		<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n		<p><strong><span style=\"color: rgb(89, 126, 170); font-family: Georgia, serif; font-size:14pt;\">Double-check all arrangements</span></strong></p>\n		</li>\n		<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n		<p><strong style=\"null\"><span style=\"font-size:14pt; color: rgb(89, 126, 170); font-family: Georgia, serif;\">Pack essentials documents and personal valuables separately</span></strong></p>\n		</li>\n		<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n		<p><strong style=\"null\"><span style=\"font-size:14pt; color: rgb(89, 126, 170); font-family: Georgia, serif;\">Complete any final cleaning of the new home if necessary</span></strong></p>\n		</li>\n	</ul>\n	</li>\n</ul>\n\n<p><strong style=\"null\"><span style=\"font-size:14pt; color: rgb(89, 126, 170); font-family: Georgia, serif;\">​</span></strong></p>\n\n<p></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 78px; top: 238px; width: 633px; height: 299px; z-index: 3;",
	cssClasses:	"",
	id:		"1565",
	htmlId:		"tobj1565",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 2"
	},
	objData:	{"a":[0,32,0,[78,238,633,299]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":78,"y":238,"width":633,"height":299},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
image1564.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<img id=\"tobj1564Img\" src=\"images/Kelly%20Avatar.png\" alt=\"Kelly Avatar\" title=\"Kelly Avatar\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 662px; height: 662px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 505px; top: 63px; width: 662px; height: 662px; z-index: 4; border-radius: 0px;",
	cssClasses:	"",
	id:		"1564",
	htmlId:		"tobj1564",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Kelly Avatar"
	},
	objData:	{"a":[0,288,0,[505,63,662,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":505,"y":63,"width":662,"height":662}}
};
rcdObj.rcdData.att_TabletLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	65
};
rcdObj.pgWidth_TabletLandscape = pgWidth_tabletLand;
rcdObj.preload_TabletLandscape = ["images/Life%20is%20a%20Game%20Bkgrnd.png","images/Kelly%20Avatar.png"];
rcdObj.pgStyle_TabletLandscape = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 730px; -webkit-print-color-adjust: exact; overflow: hidden; background-image: url("images/Life%20is%20a%20Game%20Bkgrnd.png"); background-repeat: no-repeat; background-size: 1009px 662px; visibility: hidden;'
rcdObj.backgrd_TabletLandscape = ["#FFFFFF","url(images/Life%20is%20a%20Game%20Bkgrnd.png)",1009,662,1];
