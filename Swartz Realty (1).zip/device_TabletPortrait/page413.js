if (window.VarCurrentView) VarCurrentView.set('TabletPortrait');
function init_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

}
shape423.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div id=\"tobj423inner\"><svg viewBox=\"0 0 675 408\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(337.5 204)\" style=\"\">\n	<path d=\"M 102 0 L 573 0 A 102 102 0 0 1 675 102 L 675 306 A 102 102 0 0 1 573 408 L 102 408 A 102 102 0 0 1 0 306 L 0 102 A 102 102 0 0 1 102 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55); pointer-events: auto;\" transform=\"translate(0 0) translate(-337.5, -204) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(337.5 204)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55);\">\n			<tspan x=\"0\" y=\"4.03\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 51px; top: 97px; width: 675px; height: 408px; z-index: 0; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"423",
	htmlId:		"tobj423",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rounded Rectangle"
	},
	objData:	{"a":[0,32,0,[50.99999999999994,97.00000000000009,675,408]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":65,"y":97,"width":867,"height":525},"bTriggerScreenRdrOnShow":false,"bDiscoverable":false,"altValue":"Rounded Rectangle","titleValue":"Rounded Rectangle"}
};
text439.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 484px; min-height: 310px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 474px; min-height: 300px;\"><p style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\"><span style=\"font-size:16pt;\"><strong><strong style=\"null\"><span style=\"font-family: Georgia, serif; color: rgb(89, 126, 170);\">Decide how much you can afford on a mortgage and homebuying fees. This may include:</span></strong></strong></span></p>\n\n<ul style=\"padding-inline-start: 31px;\">\n	<li style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><span style=\"font-size:16pt;\"><strong><strong style=\"null\"><span style=\"font-family: Georgia, serif; color: rgb(89, 126, 170);\">HOA fees&nbsp;</span></strong></strong></span></li>\n	<li style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><span style=\"font-size:16pt;\"><strong><strong style=\"null\"><span style=\"font-family: Georgia, serif; color: rgb(89, 126, 170);\">Property tax costs&nbsp;</span></strong></strong></span></li>\n	<li style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><strong><strong style=\"null\"><span style=\"font-size:16pt; font-family: Georgia, serif; color: rgb(89, 126, 170);\">Homeowner’s insurance</span></strong></strong></li>\n	<li style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><strong><strong style=\"null\"><span style=\"font-size:16pt; font-family: Georgia, serif; color: rgb(89, 126, 170);\">Home maintenance</span></strong></strong></li>\n</ul>\n\n<p style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><strong><strong style=\"null\"><span style=\"font-size:16pt; font-family: Georgia, serif; color: rgb(89, 126, 170);\">​</span></strong></strong></p>\n\n<p style=\"font-family: Georgia, serif; font-size:16pt; color: rgb(89, 126, 170);\"><strong><strong style=\"null\"><span style=\"font-size:16pt; font-family: Georgia, serif; color: rgb(89, 126, 170);\">Now is the time to make a thorough budget to see how much home you can realistically afford</span></strong></strong></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 146px; top: 166px; width: 484px; height: 310px; z-index: 1;",
	cssClasses:	"",
	id:		"439",
	htmlId:		"tobj439",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[0,32,0,[146,166,484,310]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":188,"y":166,"width":622,"height":398},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
image422.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<img id=\"tobj422Img\" src=\"images/Kelly%20Avatar.png\" alt=\"Kelly Avatar\" title=\"Kelly Avatar\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 329px; height: 329px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 538px; top: 258px; width: 329px; height: 329px; z-index: 2; border-radius: 0px;",
	cssClasses:	"",
	id:		"422",
	htmlId:		"tobj422",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Kelly Avatar"
	},
	objData:	{"a":[0,288,0,[538,258,329,329]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":691,"y":258,"width":423,"height":423}}
};
rcdObj.rcdData.att_TabletPortrait = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	65
};
rcdObj.pgWidth_TabletPortrait = pgWidth_tabletPort;
rcdObj.preload_TabletPortrait = ["images/Life%20is%20a%20Game%20Bkgrnd.png","images/Kelly%20Avatar.png"];
rcdObj.pgStyle_TabletPortrait = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 1000px; -webkit-print-color-adjust: exact; overflow: hidden; background-image: url("images/Life%20is%20a%20Game%20Bkgrnd.png"); background-repeat: no-repeat; background-size: 785px 515px; visibility: hidden;'
rcdObj.backgrd_TabletPortrait = ["#FFFFFF","url(images/Life%20is%20a%20Game%20Bkgrnd.png)",1009,662,0.777998017839445];
