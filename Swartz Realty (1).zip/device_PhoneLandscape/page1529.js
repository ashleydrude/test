if (window.VarCurrentView) VarCurrentView.set('PhoneLandscape');
function init_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

}
shape1541.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj1541inner\"><svg viewBox=\"0 0 641 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(320.5 40)\" style=\"\">\n	<path d=\"M 40 0 L 601 0 A 40 40 0 0 1 641 40 L 641 40 A 40 40 0 0 1 601 80 L 40 80 A 40 40 0 0 1 0 40 L 0 40 A 40 40 0 0 1 40 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55); pointer-events: auto;\" transform=\"translate(0 0) translate(-320.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(320.5 40)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.55;filter:alpha(opacity=55);\">\n			<tspan x=\"0\" y=\"4.03\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 131px; top: 19px; width: 641px; height: 80px; z-index: 0; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1541",
	htmlId:		"tobj1541",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Pill"
	},
	objData:	{"a":[0,32,0,[131,19.000000000000078,641,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":168,"y":25,"width":824,"height":103},"bTriggerScreenRdrOnShow":false,"bDiscoverable":false,"altValue":"Pill","titleValue":"Pill"}
};
text1542.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 661px; min-height: 86px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 651px; min-height: 76px;\"><p style=\"text-align: center;\"><span style=\"font-size:36pt; color: rgb(255, 0, 255); font-family: Impact, sans-serif;\">Hiring a Moving Company vs. DIY Move</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 133px; top: 29px; width: 661px; height: 86px; z-index: 1;",
	cssClasses:	"",
	id:		"1542",
	htmlId:		"tobj1542",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 2"
	},
	objData:	{"a":[0,32,0,[133,29,661,86]],"rcdOvr":{"res":0},"textShadowEffect":{"opacity":"0.9","depth":8,"color":"#000000","blurradius":5,"shadowtype":2,"bHasShadow":true,"dir":315},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":171,"y":37,"width":849,"height":111},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
shape1537.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj1537inner\"><svg viewBox=\"0 0 755 393\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(377.5 196.5)\" style=\"\">\n	<path d=\"M 98.25 0 L 656.75 0 A 98.25 98.25 0 0 1 755 98.25 L 755 294.75 A 98.25 98.25 0 0 1 656.75 393 L 98.25 393 A 98.25 98.25 0 0 1 0 294.75 L 0 98.25 A 98.25 98.25 0 0 1 98.25 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.75;filter:alpha(opacity=75); pointer-events: auto;\" transform=\"translate(0 0) translate(-377.5, -196.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(377.5 196.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.75;filter:alpha(opacity=75);\">\n			<tspan x=\"0\" y=\"4.03\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 16px; top: 105px; width: 755px; height: 393px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1537",
	htmlId:		"tobj1537",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rounded Rectangle"
	},
	objData:	{"a":[0,32,0,[15.999999999999943,105.00000000000009,755,393]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":21,"y":135,"width":971,"height":505},"bTriggerScreenRdrOnShow":false,"bDiscoverable":false,"altValue":"Rounded Rectangle","titleValue":"Rounded Rectangle"}
};
text1546.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 492px; min-height: 189px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 482px; min-height: 179px;\"><ul style=\"padding-inline-start: 27px;\">\n	<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n	<p><span><strong><span style=\"color: rgb(89, 126, 170); font-size:14pt; font-family: Georgia, serif;\">Research local moving companies, noting costs, availability, and services offered (e.g., packing, loading/unloading).</span></strong></span></p>\n	</li>\n</ul>\n\n<p><strong style=\"null\"><span style=\"font-size:14pt; color: rgb(89, 126, 170); font-family: Georgia, serif;\">​</span></strong></p>\n\n<ul style=\"padding-inline-start: 27px;\">\n	<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n	<p><strong><span style=\"color: rgb(89, 126, 170); font-size:14pt; font-family: Georgia, serif;\">Consider the pros and cons of hiring professionals versus handling the move yourself. If handling it yourself, outline key steps for renting a moving truck, securing help, and obtaining packing materials.</span></strong></p>\n	</li>\n</ul>\n\n<p><strong style=\"null\"><span style=\"font-size:14pt; color: rgb(89, 126, 170); font-family: Georgia, serif;\">​</span></strong></p>\n\n<ul style=\"padding-inline-start: 27px;\">\n	<li style=\"font-family: Georgia, serif; font-size:14pt; color: rgb(89, 126, 170);\">\n	<p><strong><span style=\"color: rgb(89, 126, 170); font-size:14pt; font-family: Georgia, serif;\">Make a final decision, and if hiring a company, schedule the moving date.</span></strong></p>\n	</li>\n</ul></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 56px; top: 205px; width: 492px; height: 189px; z-index: 3;",
	cssClasses:	"",
	id:		"1546",
	htmlId:		"tobj1546",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 2"
	},
	objData:	{"a":[0,32,0,[56,205,492,189]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":72,"y":264,"width":633,"height":243},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
image1547.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<img id=\"tobj1547Img\" src=\"images/Kelly%20Avatar.png\" alt=\"Kelly Avatar\" title=\"Kelly Avatar\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 515px; height: 515px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 393px; top: 49px; width: 515px; height: 515px; z-index: 4; border-radius: 0px;",
	cssClasses:	"",
	id:		"1547",
	htmlId:		"tobj1547",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Kelly Avatar"
	},
	objData:	{"a":[0,288,0,[393,49,515,515]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":505,"y":63,"width":662,"height":662}}
};
rcdObj.rcdData.att_PhoneLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	65
};
rcdObj.pgWidth_PhoneLandscape = pgWidth_phoneLand;
rcdObj.preload_PhoneLandscape = ["images/Life%20is%20a%20Game%20Bkgrnd.png","images/Kelly%20Avatar.png"];
rcdObj.pgStyle_PhoneLandscape = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 569px; -webkit-print-color-adjust: exact; overflow: hidden; background-image: url("images/Life%20is%20a%20Game%20Bkgrnd.png"); background-repeat: no-repeat; background-size: 785px 515px; visibility: hidden;'
rcdObj.backgrd_PhoneLandscape = ["#FFFFFF","url(images/Life%20is%20a%20Game%20Bkgrnd.png)",1009,662,0.777998017839445];
